using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Wc3Gymnasium
{
    public partial class MainForm : Form
    {
        private List<string> rootFolders;
        private DateTime startTime;
        private bool running;
        private TimeSpan pausedTime;
        private int fontSize;
        private string keybind;
        private bool overlayMode;
        private bool waitingForKeybind;

        public MainForm()
        {
            InitializeComponent();
            InitializeWc3Gymnasium();
        }

        private void InitializeWc3Gymnasium()
        {
            Text = "wc3gymnasium";
            TopMost = true;
            Size = new Size(400, 300);
            Location = new Point(100, 100);

            rootFolders = new List<string> { @"C:\wc3gymnasium", Path.GetDirectoryName(Application.ExecutablePath) };
            startTime = DateTime.Now;
            running = true;
            pausedTime = TimeSpan.Zero;
            fontSize = 12;
            keybind = null;
            overlayMode = false;
            waitingForKeybind = false;

            CreateWidgets();
            ShowFileList();
            KeyPreview = true;
            KeyPress += HandleKeyPress;
        }

        private void CreateWidgets()
        {
            // Create and add controls (buttons, labels, etc.) here
            // This is a simplified version and doesn't include all controls from the Python version

            Button backButton = new Button
            {
                Text = "Builds",
                Width = 50,
                Enabled = false
            };
            backButton.Click += (sender, e) => ShowFileList();
            Controls.Add(backButton);

            Button increaseFontButton = new Button
            {
                Text = "+",
                Width = 30
            };
            increaseFontButton.Click += (sender, e) => IncreaseFontSize();
            Controls.Add(increaseFontButton);

            Button decreaseFontButton = new Button
            {
                Text = "-",
                Width = 30
            };
            decreaseFontButton.Click += (sender, e) => DecreaseFontSize();
            Controls.Add(decreaseFontButton);

            // Add more controls as needed

            RichTextBox listBox = new RichTextBox
            {
                Font = new Font("Arial Narrow", fontSize),
                ReadOnly = true,
                Dock = DockStyle.Fill
            };
            listBox.MouseDoubleClick += DisplayFileContent;
            Controls.Add(listBox);

            Timer timer = new Timer
            {
                Interval = 1000
            };
            timer.Tick += UpdateTimer;
            timer.Start();
        }

        private void ShowFileList()
        {
            RichTextBox listBox = Controls.OfType<RichTextBox>().FirstOrDefault();
            if (listBox == null) return;

            listBox.Clear();
            HashSet<string> mdFiles = new HashSet<string>();
            foreach (string folder in rootFolders)
            {
                string[] files = Directory.GetFiles(folder, "*.md");
                mdFiles.UnionWith(files.Select(Path.GetFileNameWithoutExtension));
            }
            listBox.Text = string.Join(Environment.NewLine, mdFiles.OrderBy(f => f));

            Button backButton = Controls.OfType<Button>().FirstOrDefault(b => b.Text == "Builds" || b.Text == "← Back");
            if (backButton != null)
            {
                backButton.Text = "Builds";
                backButton.Enabled = false;
            }
        }

        private void DisplayFileContent(object sender, MouseEventArgs e)
        {
            RichTextBox listBox = sender as RichTextBox;
            if (listBox == null) return;

            int charIndex = listBox.GetCharIndexFromPosition(e.Location);
            int lineIndex = listBox.GetLineFromCharIndex(charIndex);
            string line = listBox.Lines[lineIndex].Trim();

            if (!string.IsNullOrEmpty(line))
            {
                foreach (string folder in rootFolders)
                {
                    string filePath = Path.Combine(folder, line + ".md");
                    if (File.Exists(filePath))
                    {
                        string content = File.ReadAllText(filePath);
                        ApplyMarkdownStyles(content);

                        Button backButton = Controls.OfType<Button>().FirstOrDefault(b => b.Text == "Builds" || b.Text == "← Back");
                        if (backButton != null)
                        {
                            backButton.Text = "← Back";
                            backButton.Enabled = true;
                        }
                        break;
                    }
                }
            }
        }

        private void ApplyMarkdownStyles(string content)
        {
            // This is a simplified version and doesn't include full Markdown parsing
            RichTextBox listBox = Controls.OfType<RichTextBox>().FirstOrDefault();
            if (listBox == null) return;

            listBox.Clear();
            string[] lines = content.Split('\n');
            foreach (string line in lines)
            {
                if (line.StartsWith("# "))
                {
                    listBox.SelectionFont = new Font(listBox.Font.FontFamily, fontSize + 8, FontStyle.Bold);
                    listBox.AppendText(line.Substring(2) + Environment.NewLine);
                }
                else if (line.StartsWith("## "))
                {
                    listBox.SelectionFont = new Font(listBox.Font.FontFamily, fontSize + 6, FontStyle.Bold);
                    listBox.AppendText(line.Substring(3) + Environment.NewLine);
                }
                else if (line.StartsWith("### "))
                {
                    listBox.SelectionFont = new Font(listBox.Font.FontFamily, fontSize + 4, FontStyle.Bold);
                    listBox.AppendText(line.Substring(4) + Environment.NewLine);
                }
                else
                {
                    listBox.SelectionFont = new Font(listBox.Font.FontFamily, fontSize, FontStyle.Regular);
                    listBox.AppendText(line + Environment.NewLine);
                }
            }
        }

        private void UpdateTimer(object sender, EventArgs e)
        {
            if (running)
            {
                TimeSpan elapsed = DateTime.Now - startTime;
                Label timerLabel = Controls.OfType<Label>().FirstOrDefault(l => l.Name == "timerLabel");
                if (timerLabel != null)
                {
                    timerLabel.Text = $"{elapsed.Hours:D2}:{elapsed.Minutes:D2}:{elapsed.Seconds:D2}";
                }
            }
        }

        private void IncreaseFontSize()
        {
            fontSize++;
            UpdateFontSize();
        }

        private void DecreaseFontSize()
        {
            if (fontSize > 8)
            {
                fontSize--;
            }
            UpdateFontSize();
        }

        private void UpdateFontSize()
        {
            RichTextBox listBox = Controls.OfType<RichTextBox>().FirstOrDefault();
            if (listBox == null) return;

            listBox.Font = new Font("Arial Narrow", fontSize);
            if (!string.IsNullOrWhiteSpace(listBox.Text))
            {
                ApplyMarkdownStyles(listBox.Text);
            }
        }

        private void HandleKeyPress(object sender, KeyPressEventArgs e)
        {
            if (waitingForKeybind)
            {
                keybind = e.KeyChar.ToString();
                waitingForKeybind = false;
                Button keybindButton = Controls.OfType<Button>().FirstOrDefault(b => b.Name == "keybindButton");
                if (keybindButton != null)
                {
                    keybindButton.Text = keybind;
                }
            }
            else if (keybind != null && e.KeyChar.ToString() == keybind)
            {
                ToggleOverlayMode();
            }
        }

        private void ToggleOverlayMode()
        {
            overlayMode = !overlayMode;
            // Implement overlay mode logic here
        }
    }
}