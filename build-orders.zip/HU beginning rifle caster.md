﻿# BEGINNER RIFLE CASTER

T1: Make a peasant. Constantly produce them
- 4 peasants mine gold
- 1 peasant builds an altar
First four peasants as they spawn:
- Barracks
- Farm
- Mine gold
- Farm
*10/18:* Altar finishes: Archmage
*16/18:* Barracks finishes: Footman. Constantly produce  
*18/18:* Farm
*21/24:* First footman spawns. scout opponent
*21/24:* Scout tower
*22/24:* Pause peasant production
*22/24:* Archmage spawns: Call 5 militia and start creeping 
*24/30:* Upgrade to arcane tower
*24/30:* Make one final peasant. 
	(14 total: 5 on gold, 9 on lumber)
*29/30:* Stop making footmen. You should have 5 total
*29/30:* Upgrade to Keep T2

`T2: 3:10 Benchmark (17:30 in-game time): 
	Your keep should start now, which is 10 seconds before nightfall.`

Build these ASAP: 
- Defend
- Arcane vault
- Blacksmith
- Farm
- Farm
Blacksmith finishes: Start riflemen production 
Keep finishes:
- Mountain king
- Arcane sanctum (power build with 2 peasants) 
Arcane sanctum finishes: Start priest production
Research the following upgrades whenever you can:
- Long rifles
- Priest adept training
- +1 ranged attack

`7:20 Benchmark (06:00 in-game time): 
This is the dawn of the second day in game. 
49 or *50 food* if you didn't lose any units.
you have upgrades on the way!`

https://warcraft-gym.com/human-beginner-rifle-caster/