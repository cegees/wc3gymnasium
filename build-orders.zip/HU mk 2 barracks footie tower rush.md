# MK 2 BARRACKS FOOTMEN TOWER RUSH

T1: Make a peasant. Constantly produce them
- 4 peasants mine gold
- 1 peasant builds an altar
5/12 After farm use peasant to build an altar.
First four peasants as they spawn:
- Barracks
- Farm
- Mine gold
- Mine gold
9/12 When the 4th peasant is half trained, send 1 peasant on gold to build a 2nd farm and shiftclick to build a 3rd farm.
11/18 Build MK and 1st footman.
19/24 Make 2nd footman.
22/24 Make 4th farm with the peasant building the 3rd farm.
22/24 when MK is out militia creep 
22/30 Build 2nd rax and produce 3rd footman when available.
24/30 Queue 1 peasant.
25/30 Build Lumbermill.
25/36 Research Defend.
25/36 Continue building footman and when it turns night pull 4 militia and start running across to the enemy base.
?/36 Make a stop to the goblin merchant with your hero and sell all items and buy boots of speed, circlet and dust if against NE.
?/36 Continue building footies from 2 your two barracks and go to the enemy base and begin constructing towers. Build an arcane tower first then guard towers.
?/36 You may add more farms if you're supply blocked and haven't lost many units.
?/36 Once you hit level 2 on your MK skill lvl 1 bash.

https://warcraft-gym.com/mk-2-barracks-footmen-tower-rush/