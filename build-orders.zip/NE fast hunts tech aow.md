﻿AOW FAST HUNTS TECH

5/10 Send 4 of your 5 wisps to the gold mine. Your 5th wisp should build an altar and you can then use that wisp to go scout the enemy after the altar produces.
5/10 Queue 2 wisp.
6/10 Your 1st wisp produced builds a moonwell then shift click the wisp onto a tree so the wisp will harvest lumber after. 7/10 Rally your 2nd produced wisp to the goldmine so you have 5/5 on gold.
7/10 Queue as many wisps as you can (will build a total of 8 more wisps to have 10 on wood including your scouting wisp). Rally all other wisps to harvest wood.
10/20 Start training your first hero (Keeper of the grove is good with hunts for lockdown).
18/20 When you have 160 wood build a Hunter's Hall and a build of Ancient of War (AoW).
17/20 When you have 40 wood get a 2nd moonwell.
20/30 Train a huntress
23/30 Start Tech to Tier 2 (ASAP).
23/30 At 40 wood build Moonwell #3.
23/30 Research Ultravision (ASAP).
23/30 Continue huntress producton. By Tier 2 you should have
4-5 Huntresses.


https://warcraft-gym.com/1-aow-fast-hunts-tech/