﻿FAST TECH BEARS
5/10 Put 4 wisps on gold, 5th wisp altar.
5/10 Build your 1st wisp.
6/10 Take a wisp from your gold mine when your 1st queued wisp is 2/3 done and build an ancient of war (AoW) preferably in a position to AoW Creep.
6/10 Queue your 2nd wisp.
6/10 The 1st wisp created builds a moon well.
7/10 Queue your 3rd wisp. Your 2nd and 3rd wisp created goes to the gold mine. You should have 5/5 wisps on gold. All future built wisps go to wood.
8/10 Queue your 4th wisp.
8/10 Scout with the wisp that created the altar and send the wisp that made moonwell to harvest lumber.
9/10 Build your first hero (usually demon hunter but sometimes kotg). Continue to build wisps until you have 9 wisps on wood in total in the end.
15/20 Build an archer.
18/20 Build a moon well once you hit 40 wood.
~19-20/20 When archer completes begin the AoW creep.
20/20 a wisp will be stuck in queue (your 9th wood wisp). Build an ancient of wonders (shop) with one wood wisp so your food is 19/20 and your wisp will begin to be created. Cancel the shop and you will have 21/20 food before 2nd moonwell finishes. 21/30 Build a 2nd archer. Tech to tier 2 (you should have 5 on gold, 9 on wood, 2 archers and 1 hero).
23/30 Build a 3rd archer.
25/30 Build a moon well when you have enough lumber.
25/30 Build a 4th archer.
27/30 When your tier 2 tech is 50% complete build a hunters hall.
27/30 When tier 2 and hunters hall finishes, build 1 ancient of lore and a wood wisp. 28/40 Begin your tech to tier 3.
28/40 Buy your second hero (common choices are naga, panda or keeper).
33/40 When you have enough lumber build a 2nd ancient of lore and then your shop. 33/40 when ancient of lore finishes build dyrad.
36/40+ At this point begin pumping bears. Get the adept training before tier 3. When tier 3 finishes get master bear training asap and an orb of venom for 1 of your heroes.

https://warcraft-gym.com/demon-hunter-fast-bear-tech/