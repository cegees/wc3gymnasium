﻿1ST HERO & NAGA ARCHER/DOTT PUSH

5/10 4 gold. 1 wisp altar,shift click scout after building.
5/10 Queue 1st wisp. Take a wisp from your gold mine and send it to where you want to build an ancient of war (AoW) preferably in a position to AoW Creep.
7/10 The 1st wisp created builds a moonwell and afterwards make your AoW with the wisp from the gold mine.
6/10 Queue Wisps #2 and #3 and rally both to the goldmine so you have 5 on gold. 7/10 Continue wisp production (up to 20/20 food which will be 9 on wood and 5 on gold total).
9/20 Start training your hero.
15/20 Queue your 1st archer.
18/20 As soon as you have 40 wood build your 2nd moonwell.
~19-20/20 Start AoW creeping with your first archer and AoW.
20/20 a wisp will be stuck in queue (your 9th wood wisp). Build an ancient of wonders (shop) with a wood wisp so your food is 19/20 and your wisp will begin to be created. Cancel the shop and you will have 21/20 food before 2nd moonwell finishes. 21/30 Tech to Tier 2 at your Tree of Life and then queue your 2nd archer.
23/30 Queue your 3rd archer.
25/30 Build your third moonwell and queue your 4th archer and 5th archer when you
can.
29/30 Build an ancient of wonders (shop) and queue a 6th archer.
30/40 Queue a 7th archer.
32/40 Buy Naga from the Tavern as soon as tech to tier 2 finishes start Improved Bows at AoW
37/40 Get your 4th moon well, make an Ancient of Wind, and buy a staff of preservation at your shop.
36/40 When Improved Bows completes pump archers until you reach roughly 11 archers.
?/50 When the Ancient of Wind finishes queue 2 Druids of the Talon.
Once you have Hero 1 + Naga, 11 - 12 Archers, and 2 Dotts, make your push! Bring 3-5 wisps with your push to detonate when necessary.
(Ideally, your 1st Hero will be Level 3, and you will buy 1-2 Heal Scrolls and 1-2
Protecton Scrolls on your way to push the enemy base).


https://warcraft-gym.com/1st-hero-naga-archer-dott-push/