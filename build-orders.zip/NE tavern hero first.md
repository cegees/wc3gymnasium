﻿NELF TAVERN HERO FIRST BUILD ORDER

5/10 - 4 gold, 1 lumber, q 3 whisps
7/10 - 1st Wisp = AoW
8/10 - 2nd Wisp = moonwell, q 3 more wisps
8/10 - 3rd Wisp = lumber
9/10 - 4th Wisp = altar
10/20- Train Archer(1st)  asap
12/20- q 2 more Wisps
14/20- Train archer(2nd) and move another one of your lumber wisps to a tree close to the tavern.
16/20- Queue another lumber wisp.
17/20- Queue another archer (3rd) and your final lumber wisp as soon as you can. 
20/20- pick up your neutral hero.
25/30- 25 is the food count you want to have. If you happen to lose your scout wisp you may want to rebuild it quickly before tech. You want 9 wisps on wood. 25/30 - Tech as soon as you have enough lumber. Should be during your first creep (usually AoW creep of a bigger camp).

https://warcraft-gym.com/tavern-hero-first-build-order-for-night-elf/