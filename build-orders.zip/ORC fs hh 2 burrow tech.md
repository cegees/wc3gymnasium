﻿FARSEER HEADHUNTER STANDARD 2 BURROW TECH
5/11 Queue 3 peons in your great hall.
6/11 Send 4 to gold, 5th builds an altar.
7/11 The 1st peon produced builds a burrow.
8/11 The 2nd peon gold mine to 5/5. Queue 4th peon.
9/11 The 3rd peon war mill. Queue 5th peon. 
10/11 4th peon lumber. Queue 6th peon. 
10/21 Build a farseer. Peons that built the altar and burrow gather lumber. 
16/21 The 5th produced peon builds a barracks. Queue 7th peon. 
17/21 The 6th and 7th produced peons gather lumber. Stop peon production
now.
17/21 Build a second burrow.
17/21 Skill spirit wolves and send the farseer towards the opponent for harassing (if vs NE, UD, or HU) or creeping (if vs orc).
17/21 Queue 2 headhunters as soon as the barracks finishes.
21/31 Upgrade your great hall to a stronghold
21/31 Keep headhunter production going until you have six of them.
27/31 Build a 3rd burrow or a voodoo lounge (if your farseer is low on health you might want to to build the lounge first).
29/31 Build a voodoo lounge or a third burrow (the one you didn't build previously).
34/41 As soon as tier 2 finishes, start/get a second hero (most common is the tauren chieftain).
34/41 Optional: if a lot of your headhunters are hurt get the troll
regeneration upgrade or get it later.
34/41 Build up to two tier 2 buildings depending on what you want your end game composition to be.

https://warcraft-gym.com/farseer-headhunter-standard-2-burrow-tech/