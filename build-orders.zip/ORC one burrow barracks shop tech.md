﻿1 BURROW, BARRACKS, AND SHOP BEFORE TECH

5/11: Send 4 of your 5 peons into the gold mine and send the 5th peon to build an Altar of Storms.
5/11: Queue up 2 peons in the great hall (your first built peon goes to gold).
6/11: When your 1st queued peon is about ~60-70% done, take 1 peon out of your gold mine and build an orc burrow.
7/11: Queue up another (3rd) peon.
8/11: Take the 2nd built peon when it is created and build a Barracks.
8/11: Queue up another (4th) peon.
9/11: Your 3rd created peon goes to gold and you now have 5 peons on gold.
9/11 Do not put more than 5 peons on gold. The rest of your peons created go to harvest lumber and all peons that make buildings harvest lumber after.
9/11: Queue up another (5th) peon.
10/21: When both your Altar and your burrow finish, train your first Hero
15/21: Queue up another (6th) peon.
16/21: As soon as you have 30 lumber, a lumber peon should build a Voodoo Lounge ("Shop"), then shift-click him back to lumber.
16/21: As soon as your Barracks finishes, train 1 Grunt (NOTE: It is correct that there will be a gap in your Peon production!)
19/21: Queue up your last (7th) peon.
20/21: As soon as you have 190 Lumber, upgrade your Great Hall to a Stronghold ("Tier 2").
20/21 Take your grunt and hero and creep one green camp before coming back to your Shop to buy items.
20/21: When you have 40 lumber take a lumber peon and build your 2nd burrow. 20/21: When you have enough resources build your 3rd burrow.
20/31: Train your second Grunt.
23/31: Train your third Grunt. Depending on your end game compositon you may not produce any more Grunts throughout the game unless you want to replace dead
ones.
Once your Tier 2 upgrade finishes, you can begin transitioning into one of multiple end game builds.

https://warcraft-gym.com/standard-1-burrow-barracks-and-shop-before-tech/