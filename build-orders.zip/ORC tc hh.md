﻿TAUREN CHIEFTAIN HEADHUNTERS

5/11 5 peons gold. Build 3 peons.
6/11 1st peon burrow 
7/11 2nd peon warmill. Build 4# peon 
8/11 3rd peon barracks. Build 5# peon
9/11 4th peon altar.
10/21 Build 6# peon. Rest on lumber
11/21 Build 7# peon.
12/21 Build 2nd burrow asap at 40 wood (using peon that last returned lumber)
12/21 When barrack finishes build headhunter
14/21 Build your TC when altar finishes (or tavern hero). Queue a 2nd headhunter.
21/21 Queue a 3rd headhunter.
23/31 When you have 2 headhunters and your TC is not yet out, you can begin to pull a green camp to damage it.
23/31 When TC comes out you should have 3 headhunters and 7 wood peons. 
23/31 You have a choice, tech after the 3rd headhunter if you want to tech quickly or build a shop when you have the resources to do so before teching if you want to be safe.
23/31 Get aura lvl 1 on TC as you want to be creeping early and not
pressuring. This will let you creep quicker.
23/31 Continue pumping headhunters as you continue to tier 2.
~27/31 Get your headhunter attack upograde after several more headhunters are made as it is cheap but strong.

https://warcraft-gym.com/quick-headhunters-and-slow-tauren-chieftain/