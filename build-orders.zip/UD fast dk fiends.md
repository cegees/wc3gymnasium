﻿FAST DK FIENDS SLAUGHTERHOUSE

5/10 3 to gold. Build 2 acolytes. 
6/10 New acolytes make ziggurat and altar.
7/10 build a crypt when 5th acolyte spawn
7/10 Build a 6th acolyte.
8/10 Build a tomb of relics with 6th acolyte, then 
 kill a critter near creeps, then scout.
8/20 Make Death Knight.
13/20 Build a graveyard.
13/20 Make 2 ghouls.
17/20 When DK spawns, purchase rod of necromancy and creep. (use rod on critter)
17/20 Build a fiend asap.
20/20 upgrade necropolis T2 
20/20 Build a ziggurat.
20/30 Build 2 fiends.
25/30 Build lich/2nd hero. 
30/30 Go tier 3. build ziggurat and slaughterhouse thereafter. 
	Or stay tier 2 and build ziggurat and slaughterhouse 
	and tech tier 3 at 39/40 food after building fiends/statues.
39/40 Build ziggurat.
39/50 Get third hero and get orb at tier 3 asap.
44/50 Build up to 50 food. 
You should have 6 fiends, 2 statues, and 3 heroes.

https://warcraft-gym.com/fast-death-knight-with-fiends-build/